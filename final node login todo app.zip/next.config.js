module.exports = {
    env: {
        MONGO_URI: "mongodb+srv://Savreen:codecorners@cluster0.ot7uo.mongodb.net/start?retryWrites=true&w=majority"
    }
}