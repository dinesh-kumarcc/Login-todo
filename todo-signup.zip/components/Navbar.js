import Link from 'next/link';

const Navbar = () => (
    <nav className="navbar">
        <Link href="/register">
            <a className="create">Click to Regiser User</a>
        </Link>
    </nav>
)

export default Navbar;