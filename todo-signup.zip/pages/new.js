import Link from 'next/link';
import { useState, useEffect } from 'react';
import fetch from 'isomorphic-unfetch';
import { Button, Form, Loader, Card } from 'semantic-ui-react';
import { useRouter } from 'next/router';
import { faPlus } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
// import { faCoffee } from '@fortawesome/free-solid-svg-icons';

const NewNote = ({ notes }) => {
    console.log(notes, 'noters')
    const [form, setForm] = useState({ title: '' });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errors, setErrors] = useState({});
    const [checked, setChecked] = useState([]);
    const router = useRouter();

    useEffect(() => {
        if (isSubmitting) {
            if (Object.keys(errors).length === 0) {
                createNote();
            }
            else {
                setIsSubmitting(false);
            }
        }
    }, [errors])

    const createNote = async () => {
        try {
            const res = await fetch('http://localhost:3000/api/notes', {
                method: 'POST',
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(form)
            })
            router.push("/home");
        } catch (error) {
            console.log(error);
        }
    }
    const handleCheck = (event) => {
        var updatedList = [...checked];
        if (event.target.checked) {
          updatedList = [...checked, event.target.value];
        } else {
          updatedList.splice(checked.indexOf(event.target.value), 1);
        }
        setChecked(updatedList);
      };
      var isChecked = (item) =>
      checked.includes(item) ? "checked-item" : "not-checked-item";

    const handleSubmit = (e) => {
        e.preventDefault();
        let errs = validate();
        setErrors(errs);
        setIsSubmitting(true);
    }

    const handleChange = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        })
    }

    const validate = () => {
        let err = {};

        if (!form.title) {
            err.title = 'Title is required';
        }
        // if (!form.description) {
        //     err.description = 'Description is required';
        // }

        return err;
    }

    return (
        <div className="form-container">
            <div style={{ height: "200px", width: "600px" }}>
                <Card>
                    <h1>THINGS TO DO</h1>
                    <div>
                        {
                            isSubmitting
                                ? <Loader active inline='centered' />
                                : <Form onSubmit={handleSubmit}>
                                    <Form.Input
                                        fluid
                                        error={errors.title ? { content: 'Please enter a title', pointing: 'below' } : null}
                                        label=''
                                        placeholder='Title'
                                        name='title'
                                        onChange={handleChange}
                                    />
                                    {/* <Button type='submit'> <FontAwesomeIcon className="button11" icon={faPlus} /></Button> */}
                                </Form>
                        }
                    </div>
                    <div style={{paddingTop:"40px"}}>
                        {notes.map((note,index) => {
                            // console.log(index,'note',note,'note')
                            
                            return (
                                <div key={note._id} style={{textAlign:"center",paddingLeft:"40px",paddingRight:"40px"}}>
                                    <input value={note.title} type="checkbox" onChange={handleCheck}/>
                                   <span className={isChecked(note)}>{note.title}</span>
                                   <hr/>
                                </div>
                            )
                        })}
                    </div>
                    <Button type='submit'> <FontAwesomeIcon className="button11" icon={faPlus} /></Button>

                </Card>
            </div>
            {/* <div>
                {
                    isSubmitting
                        ? <Loader active inline='centered' />
                        : <Form onSubmit={handleSubmit}>
                            <Form.Input
                                fluid
                                error={errors.title ? { content: 'Please enter a title', pointing: 'below' } : null}
                                label='Title'
                                placeholder='Title'
                                name='title'
                                onChange={handleChange}
                            />
                            <Form.TextArea
                                fluid
                                label='Descriprtion'
                                placeholder='Description'
                                name='description'
                                error={errors.description ? { content: 'Please enter a description', pointing: 'below' } : null}
                                onChange={handleChange}
                            />
                            <Button type='submit'>Create</Button>
                        </Form>
                }
            </div> */}
        </div>
    )
}


NewNote.getInitialProps = async () => {
    const res = await fetch('http://localhost:3000/api/notes');
    const { data } = await res.json();

    return { notes: data }
}

export default NewNote;